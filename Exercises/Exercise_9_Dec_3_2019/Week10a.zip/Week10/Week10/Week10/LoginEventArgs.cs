﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week10
{
    public  delegate void LoginEventHandler(object sender, LoginEventArgs args);
    public class LoginEventArgs:EventArgs
    {
        private string userName;
        private string password;
        public LoginEventArgs(string userName, string password)
        {
            UserName = userName;
            Password = password;
        }
        public string Password
        {
            get { return password; }
            private set { password = value; }
        }

        public string UserName
        {
            get { return userName; }
            private set { userName = value; }
        }

    }
}
