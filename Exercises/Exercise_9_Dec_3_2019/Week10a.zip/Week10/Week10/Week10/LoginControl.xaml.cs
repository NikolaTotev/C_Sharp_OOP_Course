﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Week10
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class LoginControl : UserControl
    {
        public event LoginEventHandler Login; // publish Login event
        public LoginControl()
        {
            InitializeComponent();
        }

         

        public string Password
        {
            get { return txtPassword.Password; }
            set { txtPassword.Password = value; }
        }
        public string UserName
        {
            get { return txtUserName.Text; }
            set { txtUserName.Text = value; }
        }


        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            txtPassword.Password = string.Empty;
            txtUserName.Text = string.Empty;
        }

        protected virtual void OnLogin(LoginEventArgs args) => Login?.Invoke(this, args);

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            OnLogin(new LoginEventArgs(txtUserName.Text, txtPassword.Password));
        }
    }
}
